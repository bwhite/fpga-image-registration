#define TESTAPP_GEN

/* $Id: iic_header.h,v 1.1 2007/12/03 15:44:57 meinelte Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus IicSelfTestExample(Xuint16 DeviceId);


