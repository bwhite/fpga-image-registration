#define TESTAPP_GEN

#include "xbasic_types.h"
#include "xstatus.h"

int TemacPolledExample(u16 TemacDeviceId, u16 FifoDeviceId);

