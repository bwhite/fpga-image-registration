#define TESTAPP_GEN

/* $Id: sysace_header.h,v 1.2 2007/05/18 06:40:47 svemula Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus SysAceSelfTestExample(Xuint16 DeviceId);


