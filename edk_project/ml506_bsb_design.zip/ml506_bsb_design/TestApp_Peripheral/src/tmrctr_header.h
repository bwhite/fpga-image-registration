#define TESTAPP_GEN

/* $Id: tmrctr_header.h,v 1.1 2007/05/15 08:52:32 mta Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus TmrCtrSelfTestExample(Xuint16 DeviceId, Xuint8 TmrCtrNumber);


