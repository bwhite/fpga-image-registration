#define TESTAPP_GEN

/* $Id: uartlite_header.h,v 1.1.2.1 2008/02/12 12:42:01 svemula Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus UartLiteSelfTestExample(Xuint16 DeviceId);


