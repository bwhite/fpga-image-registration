#define TESTAPP_GEN

/* $Id: uartns550_header.h,v 1.2 2007/05/18 06:55:23 svemula Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus UartNs550SelfTestExample(Xuint16 DeviceId);

